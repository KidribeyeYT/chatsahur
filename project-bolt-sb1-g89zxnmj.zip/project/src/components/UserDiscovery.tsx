import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Profile } from '@/lib/supabase';
import { UserPlus, Check, MessageCircle, X, Search } from 'lucide-react';

type Props = {
  onStartDM: (userId: string) => Promise<void>;
};

export function UserDiscovery({ onStartDM }: Props) {
  const { profile } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [followingIds, setFollowingIds] = useState<Set<string>>(new Set());

  async function loadUsers() {
    if (!profile) return;
    setLoading(true);

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .neq('id', profile.id)
      .order('created_at', { ascending: false });

    if (error || !data) {
      setLoading(false);
      return;
    }
    setUsers(data as Profile[]);

    const { data: follows } = await supabase
      .from('follows')
      .select('followee_id')
      .eq('follower_id', profile.id);

    setFollowingIds(new Set((follows || []).map((f) => f.followee_id)));
    setLoading(false);
  }

  async function toggleFollow(userId: string) {
    if (!profile) return;

    if (followingIds.has(userId)) {
      await supabase.from('follows').delete().eq('follower_id', profile.id).eq('followee_id', userId);
      setFollowingIds((prev) => {
        const next = new Set(prev);
        next.delete(userId);
        return next;
      });
    } else {
      await supabase.from('follows').insert({ follower_id: profile.id, followee_id: userId });
      setFollowingIds((prev) => new Set(prev).add(userId));
    }
  }

  // Load on mount
  useState(() => {
    loadUsers();
  });

  const filtered = users.filter(
    (u) =>
      u.username.toLowerCase().includes(search.toLowerCase()) ||
      u.display_name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-slate-700/50">
        <h2 className="text-white font-semibold text-lg mb-3">Discover People</h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or username..."
            className="w-full bg-slate-800/60 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-teal-500 transition"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-2 border-teal-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-400 text-sm">
            {search ? 'No users found matching your search.' : 'No other users yet.'}
          </div>
        ) : (
          filtered.map((user) => {
            const initials = user.display_name
              .split(' ')
              .map((w) => w[0])
              .slice(0, 2)
              .join('')
              .toUpperCase();
            const isFollowing = followingIds.has(user.id);

            return (
              <div
                key={user.id}
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-800/40 transition group"
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-500 to-slate-700 flex items-center justify-center text-white font-semibold text-sm shrink-0">
                  {initials}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium truncate">{user.display_name}</p>
                  <p className="text-slate-400 text-xs truncate">@{user.username}</p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => toggleFollow(user.id)}
                    className={`flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg transition ${
                      isFollowing
                        ? 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                        : 'bg-teal-500/20 text-teal-400 hover:bg-teal-500/30'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        Following
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        Follow
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => onStartDM(user.id)}
                    className="p-1.5 text-slate-400 hover:text-teal-400 hover:bg-slate-700/50 rounded-lg transition"
                    title="Message"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
