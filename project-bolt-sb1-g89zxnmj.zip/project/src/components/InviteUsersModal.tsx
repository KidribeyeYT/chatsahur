import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Profile, type ChatWithMembers } from '@/lib/supabase';
import { X, UserPlus, Check, Search } from 'lucide-react';

type Props = {
  chat: ChatWithMembers;
  onClose: () => void;
};

export function InviteUsersModal({ chat, onClose }: Props) {
  const { profile } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [inviting, setInviting] = useState<string | null>(null);
  const [invited, setInvited] = useState<Set<string>>(new Set());

  const memberIds = new Set(chat.members.map((m) => m.user_id));

  async function loadUsers() {
    if (!profile) return;
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .neq('id', profile.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setUsers(data as Profile[]);
    }
    setLoading(false);
  }

  useState(() => {
    loadUsers();
  });

  async function inviteUser(userId: string) {
    setInviting(userId);

    const { error } = await supabase.from('chat_members').insert({
      chat_id: chat.id,
      user_id: userId,
    });

    if (error) {
      console.error('Error inviting user:', error);
    } else {
      setInvited((prev) => new Set(prev).add(userId));
    }
    setInviting(null);
  }

  const filtered = users.filter(
    (u) =>
      (u.username.toLowerCase().includes(search.toLowerCase()) ||
        u.display_name.toLowerCase().includes(search.toLowerCase())) &&
      !memberIds.has(u.id)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-800 rounded-2xl border border-slate-700 shadow-2xl max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-slate-700/50">
          <div className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-teal-400" />
            <h2 className="text-white font-semibold">Invite to {chat.name}</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 flex-1 overflow-y-auto">
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search users to invite..."
              className="w-full bg-slate-900/60 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-teal-500 transition"
              autoFocus
            />
          </div>

          {loading ? (
            <div className="text-center py-6">
              <div className="w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto" />
            </div>
          ) : filtered.length === 0 ? (
            <p className="text-center text-slate-400 text-sm py-8">
              {search ? 'No users found matching your search.' : 'All users are already in this group.'}
            </p>
          ) : (
            <div className="space-y-1">
              {filtered.map((user) => {
                const initials = user.display_name
                  .split(' ')
                  .map((w) => w[0])
                  .slice(0, 2)
                  .join('')
                  .toUpperCase();
                const isInvited = invited.has(user.id);

                return (
                  <div
                    key={user.id}
                    className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-slate-700/50 transition"
                  >
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-slate-500 to-slate-700 flex items-center justify-center text-white font-semibold text-xs shrink-0">
                      {initials}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">{user.display_name}</p>
                      <p className="text-slate-400 text-xs truncate">@{user.username}</p>
                    </div>
                    <button
                      onClick={() => inviteUser(user.id)}
                      disabled={isInvited || inviting === user.id}
                      className={`flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg transition shrink-0 ${
                        isInvited
                          ? 'bg-teal-500/20 text-teal-400'
                          : 'bg-teal-500 text-white hover:bg-teal-400'
                      }`}
                    >
                      {isInvited ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          Invited
                        </>
                      ) : inviting === user.id ? (
                        'Inviting...'
                      ) : (
                        <>
                          <UserPlus className="w-3.5 h-3.5" />
                          Invite
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="p-5 border-t border-slate-700/50">
          <button
            onClick={onClose}
            className="w-full py-2.5 text-sm font-medium text-slate-300 bg-slate-700/50 rounded-lg hover:bg-slate-700 transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
