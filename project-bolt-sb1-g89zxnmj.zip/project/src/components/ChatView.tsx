import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Profile, type ChatWithMembers, type MessageWithSender } from '@/lib/supabase';
import { useMessages } from '@/hooks/useChats';
import { MessageBubble } from '@/components/MessageBubble';
import { Send, Image, Video, X, CornerDownRight, Users, UserPlus, ArrowLeft } from 'lucide-react';

type Props = {
  chat: ChatWithMembers;
  onBack: () => void;
  onInviteUsers: () => void;
};

export function ChatView({ chat, onBack, onInviteUsers }: Props) {
  const { profile } = useAuth();
  const { messages, loading } = useMessages(chat.id);
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState<MessageWithSender | null>(null);
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Browser notifications
  useEffect(() => {
    if (!profile?.notifications_enabled || !('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;

    const prevCount = messages.length;
    if (prevCount > 0) {
      // Check last message
      const lastMsg = messages[messages.length - 1];
      if (lastMsg && lastMsg.sender_id !== profile.id) {
        const senderName = lastMsg.sender?.display_name || 'Someone';
        const preview = lastMsg.content || `[${lastMsg.media_type}]`;
        const chatName = chat.type === 'group' ? chat.name : senderName;

        // Only notify if this is a new message (not the initial load)
        const msgTime = new Date(lastMsg.created_at).getTime();
        if (Date.now() - msgTime < 5000) {
          new Notification(`Repeatlay - ${chatName}`, {
            body: `${senderName}: ${preview}`,
          });
        }
      }
    }
  }, [messages, profile, chat]);

  async function sendMessage() {
    if (!profile || (!text.trim() && !uploading) || sending) return;
    setSending(true);

    const payload: any = {
      chat_id: chat.id,
      content: text.trim() || null,
    };

    if (replyTo) {
      payload.reply_to_id = replyTo.id;
    }

    const { error } = await supabase.from('messages').insert(payload);

    if (error) {
      console.error('Error sending message:', error);
    } else {
      setText('');
      setReplyTo(null);
    }
    setSending(false);
  }

  async function handleFileUpload(file: File, mediaType: 'image' | 'video') {
    if (!profile) return;
    setUploading(true);

    const ext = file.name.split('.').pop();
    const fileName = `${profile.id}/${Date.now()}.${ext}`;
    const filePath = `${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('chat-media')
      .upload(filePath, file);

    if (uploadError) {
      console.error('Upload error:', uploadError);
      setUploading(false);
      return;
    }

    const { data: urlData } = supabase.storage.from('chat-media').getPublicUrl(filePath);

    const payload: any = {
      chat_id: chat.id,
      media_url: urlData.publicUrl,
      media_type: mediaType,
      content: text.trim() || null,
    };

    if (replyTo) {
      payload.reply_to_id = replyTo.id;
    }

    const { error: msgError } = await supabase.from('messages').insert(payload);

    if (msgError) {
      console.error('Message error:', msgError);
    } else {
      setText('');
      setReplyTo(null);
    }
    setUploading(false);
  }

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>, mediaType: 'image' | 'video') {
    const file = e.target.files?.[0];
    if (file) {
      handleFileUpload(file, mediaType);
    }
    e.target.value = '';
  }

  // Get chat display info
  const otherMember = chat.members.find((m) => m.user_id !== profile?.id);
  const chatName = chat.type === 'group' ? (chat.name || 'Unnamed Group') : (otherMember?.profile?.display_name || 'Unknown');

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-700/50 bg-slate-800/30">
        <button
          onClick={onBack}
          className="md:hidden p-1.5 text-slate-400 hover:text-white rounded-lg transition"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div
          className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold text-sm shrink-0 ${
            chat.type === 'group' ? 'bg-gradient-to-br from-violet-500 to-violet-700' : 'bg-gradient-to-br from-teal-400 to-teal-600'
          }`}
        >
          {chat.type === 'group' ? <Users className="w-5 h-5" /> : chatName[0]?.toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-white text-sm font-medium truncate">{chatName}</p>
          {chat.type === 'group' && (
            <p className="text-slate-400 text-xs truncate">{chat.members.length} members</p>
          )}
        </div>
        {chat.type === 'group' && (
          <button
            onClick={onInviteUsers}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-700/50 text-slate-300 rounded-lg hover:bg-slate-700 transition"
          >
            <UserPlus className="w-3.5 h-3.5" />
            Invite
          </button>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3 bg-slate-900/30">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-2 border-teal-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center py-12 text-slate-400 text-sm">
            No messages yet. Say hello!
          </div>
        ) : (
          messages.map((msg) => (
            <MessageBubble
              key={msg.id}
              message={msg}
              onReply={(m) => setReplyTo(m)}
            />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Reply preview */}
      {replyTo && (
        <div className="px-4 py-2 bg-slate-800/50 border-t border-slate-700/50 flex items-center gap-2">
          <CornerDownRight className="w-4 h-4 text-teal-400 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-teal-400 font-medium">
              Replying to {replyTo.sender_id === profile?.id ? 'yourself' : replyTo.sender?.display_name}
            </p>
            <p className="text-xs text-slate-400 truncate">
              {replyTo.content || `[${replyTo.media_type}]`}
            </p>
          </div>
          <button onClick={() => setReplyTo(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Input */}
      <div className="px-4 py-3 border-t border-slate-700/50 bg-slate-800/30">
        <div className="flex items-center gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleFileSelect(e, 'image')}
          />
          <input
            ref={videoInputRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={(e) => handleFileSelect(e, 'video')}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="p-2 text-slate-400 hover:text-teal-400 transition disabled:opacity-50"
            title="Send image"
          >
            <Image className="w-5 h-5" />
          </button>
          <button
            onClick={() => videoInputRef.current?.click()}
            disabled={uploading}
            className="p-2 text-slate-400 hover:text-teal-400 transition disabled:opacity-50"
            title="Send video"
          >
            <Video className="w-5 h-5" />
          </button>
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            placeholder={uploading ? 'Uploading...' : 'Type a message...'}
            disabled={sending || uploading}
            className="flex-1 bg-slate-800/60 border border-slate-700 rounded-full px-4 py-2.5 text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-teal-500 transition"
          />
          <button
            onClick={sendMessage}
            disabled={sending || uploading || (!text.trim())}
            className="p-2.5 bg-teal-500 hover:bg-teal-400 disabled:opacity-40 text-white rounded-full transition shadow-lg shadow-teal-500/20"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
