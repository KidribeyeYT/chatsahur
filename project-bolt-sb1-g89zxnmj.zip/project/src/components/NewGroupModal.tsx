import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Profile } from '@/lib/supabase';
import { X, Users, Check, Search } from 'lucide-react';

type Props = {
  onClose: () => void;
  onCreated: (chatId: string) => void;
};

export function NewGroupModal({ onClose, onCreated }: Props) {
  const { profile } = useAuth();
  const [name, setName] = useState('');
  const [users, setUsers] = useState<Profile[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  async function loadUsers() {
    if (!profile) return;
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .neq('id', profile.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setUsers(data as Profile[]);
    }
    setLoading(false);
  }

  useState(() => {
    loadUsers();
  });

  function toggleSelect(userId: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(userId)) next.delete(userId);
      else next.add(userId);
      return next;
    });
  }

  async function createGroup() {
    if (!profile || !name.trim() || selected.size === 0) return;
    setCreating(true);

    // Create the chat
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .insert({
        name: name.trim(),
        type: 'group',
        created_by: profile.id,
      })
      .select()
      .single();

    if (chatError || !chat) {
      console.error('Error creating group:', chatError);
      setCreating(false);
      return;
    }

    // Add creator as member
    const members = [
      { chat_id: chat.id, user_id: profile.id },
      ...Array.from(selected).map((userId) => ({ chat_id: chat.id, user_id: userId })),
    ];

    const { error: memberError } = await supabase.from('chat_members').insert(members);

    if (memberError) {
      console.error('Error adding members:', memberError);
    }

    setCreating(false);
    onCreated(chat.id);
  }

  const filtered = users.filter(
    (u) =>
      u.username.toLowerCase().includes(search.toLowerCase()) ||
      u.display_name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-800 rounded-2xl border border-slate-700 shadow-2xl max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-slate-700/50">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-teal-400" />
            <h2 className="text-white font-semibold">New Group Chat</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 flex-1 overflow-y-auto">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Group Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="My Awesome Group"
              className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-4 py-2.5 text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-teal-500 transition"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Select Members ({selected.size} selected)
            </label>
            <div className="relative mb-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search users..."
                className="w-full bg-slate-900/60 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-teal-500 transition"
              />
            </div>

            <div className="space-y-1 max-h-48 overflow-y-auto">
              {loading ? (
                <div className="text-center py-6">
                  <div className="w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto" />
                </div>
              ) : filtered.length === 0 ? (
                <p className="text-center text-slate-400 text-sm py-4">No users found</p>
              ) : (
                filtered.map((user) => {
                  const isSelected = selected.has(user.id);
                  const initials = user.display_name
                    .split(' ')
                    .map((w) => w[0])
                    .slice(0, 2)
                    .join('')
                    .toUpperCase();

                  return (
                    <button
                      key={user.id}
                      onClick={() => toggleSelect(user.id)}
                      className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition text-left ${
                        isSelected ? 'bg-teal-500/15' : 'hover:bg-slate-700/50'
                      }`}
                    >
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-slate-500 to-slate-700 flex items-center justify-center text-white font-semibold text-xs shrink-0">
                        {initials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white text-sm font-medium truncate">{user.display_name}</p>
                        <p className="text-slate-400 text-xs truncate">@{user.username}</p>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition ${
                          isSelected ? 'bg-teal-500 border-teal-500' : 'border-slate-600'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>

        <div className="p-5 border-t border-slate-700/50 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 text-sm font-medium text-slate-300 bg-slate-700/50 rounded-lg hover:bg-slate-700 transition"
          >
            Cancel
          </button>
          <button
            onClick={createGroup}
            disabled={creating || !name.trim() || selected.size === 0}
            className="flex-1 py-2.5 text-sm font-medium text-white bg-teal-500 rounded-lg hover:bg-teal-400 disabled:opacity-40 transition"
          >
            {creating ? 'Creating...' : 'Create Group'}
          </button>
        </div>
      </div>
    </div>
  );
}
