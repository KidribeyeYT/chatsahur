import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type ChatWithMembers } from '@/lib/supabase';
import { MessageCircle, Users, Plus, Search } from 'lucide-react';

type Props = {
  chats: ChatWithMembers[];
  loading: boolean;
  activeChatId: string | null;
  onSelectChat: (chatId: string) => void;
  onNewGroup: () => void;
};

export function ChatList({ chats, loading, activeChatId, onSelectChat, onNewGroup }: Props) {
  const { profile } = useAuth();
  const [search, setSearch] = useState('');

  if (!profile) return null;

  function getChatDisplay(chat: ChatWithMembers): { name: string; avatar: string; isGroup: boolean } {
    if (chat.type === 'group') {
      return {
        name: chat.name || 'Unnamed Group',
        avatar: (chat.name || 'G')[0].toUpperCase(),
        isGroup: true,
      };
    }
    const otherMember = chat.members.find((m) => m.user_id !== profile?.id);
    const name = otherMember?.profile?.display_name || 'Unknown';
    return {
      name,
      avatar: name.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase(),
      isGroup: false,
    };
  }

  const filtered = chats.filter((chat) => {
    const { name } = getChatDisplay(chat);
    return name.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-slate-700/50">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-white font-semibold text-lg">Chats</h2>
          <button
            onClick={onNewGroup}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-teal-500/20 text-teal-400 rounded-lg hover:bg-teal-500/30 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            New Group
          </button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search chats..."
            className="w-full bg-slate-800/60 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-teal-500 transition"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-2 border-teal-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 px-4">
            <MessageCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-400 text-sm mb-1">No chats yet</p>
            <p className="text-slate-500 text-xs">Start a DM from Discover or create a group</p>
          </div>
        ) : (
          filtered.map((chat) => {
            const { name, avatar, isGroup } = getChatDisplay(chat);
            const isActive = chat.id === activeChatId;
            const lastMsg = chat.last_message;
            const lastMsgPreview = lastMsg?.content || (lastMsg?.media_type ? `[${lastMsg.media_type}]` : '') || '';

            return (
              <button
                key={chat.id}
                onClick={() => onSelectChat(chat.id)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl transition text-left ${
                  isActive ? 'bg-teal-500/15' : 'hover:bg-slate-800/40'
                }`}
              >
                <div
                  className={`w-11 h-11 rounded-full flex items-center justify-center text-white font-semibold text-sm shrink-0 ${
                    isGroup ? 'bg-gradient-to-br from-violet-500 to-violet-700' : 'bg-gradient-to-br from-teal-400 to-teal-600'
                  }`}
                >
                  {isGroup ? <Users className="w-5 h-5" /> : avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className={`text-sm font-medium truncate ${isActive ? 'text-teal-400' : 'text-white'}`}>{name}</p>
                    {lastMsg && (
                      <p className="text-slate-500 text-xs shrink-0">
                        {new Date(lastMsg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    )}
                  </div>
                  {lastMsg && <p className="text-slate-400 text-xs truncate mt-0.5">{lastMsgPreview}</p>}
                  {chat.type === 'group' && (
                    <p className="text-slate-500 text-xs mt-0.5">{chat.members.length} members</p>
                  )}
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}
