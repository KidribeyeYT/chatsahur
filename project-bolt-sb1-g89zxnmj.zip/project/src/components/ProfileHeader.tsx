import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { MessageCircle, LogOut, Bell, BellOff, Edit2, Users, X, Check } from 'lucide-react';

type Props = {
  onNavigate: (view: 'chats' | 'users') => void;
  currentView: 'chats' | 'users';
};

export function ProfileHeader({ onNavigate, currentView }: Props) {
  const { profile, signOut, refreshProfile } = useAuth();
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(profile?.display_name || '');
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    if (!profile || displayName.trim().length < 1) return;
    setSaving(true);
    const { error } = await supabase
      .from('profiles')
      .update({ display_name: displayName.trim() })
      .eq('id', profile.id);
    if (!error) {
      await refreshProfile();
      setEditing(false);
    }
    setSaving(false);
  }

  async function toggleNotifications() {
    if (!profile) return;
    const newValue = !profile.notifications_enabled;

    if (newValue) {
      if ('Notification' in window) {
        const permission = await Notification.requestPermission();
        if (permission !== 'granted') {
          return;
        }
      }
    }

    const { error } = await supabase
      .from('profiles')
      .update({ notifications_enabled: newValue })
      .eq('id', profile.id);
    if (!error) {
      await refreshProfile();
    }
  }

  if (!profile) return null;

  const initials = profile.display_name
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <div className="border-b border-slate-700/50 bg-slate-800/30">
      <div className="px-4 py-3 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white font-semibold text-sm shrink-0">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          {editing ? (
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="flex-1 bg-slate-700 border border-slate-600 rounded-lg px-2 py-1 text-white text-sm focus:outline-none focus:border-teal-500"
                autoFocus
              />
              <button onClick={handleSave} disabled={saving} className="text-teal-400 hover:text-teal-300">
                <Check className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setEditing(false);
                  setDisplayName(profile.display_name);
                }}
                className="text-slate-400 hover:text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <>
              <p className="text-white text-sm font-medium truncate">{profile.display_name}</p>
              <p className="text-slate-400 text-xs truncate">@{profile.username}</p>
            </>
          )}
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {!editing && (
            <button
              onClick={() => {
                setDisplayName(profile.display_name);
                setEditing(true);
              }}
              className="p-2 text-slate-400 hover:text-teal-400 hover:bg-slate-700/50 rounded-lg transition"
              title="Edit display name"
            >
              <Edit2 className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={toggleNotifications}
            className={`p-2 rounded-lg transition ${
              profile.notifications_enabled
                ? 'text-teal-400 hover:bg-slate-700/50'
                : 'text-slate-400 hover:bg-slate-700/50'
            }`}
            title={profile.notifications_enabled ? 'Notifications on' : 'Notifications off'}
          >
            {profile.notifications_enabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
          </button>
          <button
            onClick={signOut}
            className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-700/50 rounded-lg transition"
            title="Sign out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="px-4 pb-3 flex gap-2">
        <button
          onClick={() => onNavigate('chats')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition ${
            currentView === 'chats'
              ? 'bg-teal-500/20 text-teal-400'
              : 'text-slate-400 hover:bg-slate-700/50'
          }`}
        >
          <MessageCircle className="w-3.5 h-3.5" />
          Chats
        </button>
        <button
          onClick={() => onNavigate('users')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition ${
            currentView === 'users'
              ? 'bg-teal-500/20 text-teal-400'
              : 'text-slate-400 hover:bg-slate-700/50'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          Discover
        </button>
      </div>
    </div>
  );
}
