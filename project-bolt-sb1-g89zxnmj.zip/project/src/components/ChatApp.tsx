import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useChats } from '@/hooks/useChats';
import { supabase, type ChatWithMembers } from '@/lib/supabase';
import { ProfileHeader } from '@/components/ProfileHeader';
import { ChatList } from '@/components/ChatList';
import { ChatView } from '@/components/ChatView';
import { UserDiscovery } from '@/components/UserDiscovery';
import { NewGroupModal } from '@/components/NewGroupModal';
import { InviteUsersModal } from '@/components/InviteUsersModal';
import { MessageCircle } from 'lucide-react';

export function ChatApp() {
  const { profile } = useAuth();
  const { chats, loading, reload } = useChats();
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [sidebarView, setSidebarView] = useState<'chats' | 'users'>('chats');
  const [showNewGroup, setShowNewGroup] = useState(false);
  const [showInvite, setShowInvite] = useState(false);
  const [mobileView, setMobileView] = useState<'sidebar' | 'chat'>('sidebar');

  const activeChat = chats.find((c) => c.id === activeChatId) || null;

  function selectChat(chatId: string) {
    setActiveChatId(chatId);
    setMobileView('chat');
  }

  async function startDM(userId: string): Promise<void> {
    if (!profile) return;

    // Check if a DM already exists between these two users
    const { data: existingMemberships } = await supabase
      .from('chat_members')
      .select('chat_id')
      .eq('user_id', profile.id);

    if (existingMemberships && existingMemberships.length > 0) {
      const myChatIds = existingMemberships.map((m) => m.chat_id);

      for (const chatId of myChatIds) {
        const { data: otherMembership } = await supabase
          .from('chat_members')
          .select('chat_id, user_id')
          .eq('chat_id', chatId)
          .eq('user_id', userId)
          .maybeSingle();

        if (otherMembership) {
          // Check if it's a DM (only 2 members)
          const { data: chatRow } = await supabase
            .from('chats')
            .select('*')
            .eq('id', chatId)
            .maybeSingle();

          if (chatRow && chatRow.type === 'dm') {
            selectChat(chatId);
            setSidebarView('chats');
            return;
          }
        }
      }
    }

    // Create new DM
    const { data: newChat, error: chatError } = await supabase
      .from('chats')
      .insert({
        type: 'dm',
        created_by: profile.id,
      })
      .select()
      .single();

    if (chatError || !newChat) {
      console.error('Error creating DM:', chatError);
      return;
    }

    // Add both users as members
    const { error: memberError } = await supabase.from('chat_members').insert([
      { chat_id: newChat.id, user_id: profile.id },
      { chat_id: newChat.id, user_id: userId },
    ]);

    if (memberError) {
      console.error('Error adding DM members:', memberError);
      return;
    }

    await reload();
    selectChat(newChat.id);
    setSidebarView('chats');
  }

  async function handleGroupCreated(chatId: string) {
    setShowNewGroup(false);
    await reload();
    selectChat(chatId);
  }

  return (
    <div className="h-screen flex bg-slate-900 overflow-hidden">
      {/* Sidebar */}
      <div
        className={`${
          mobileView === 'sidebar' ? 'flex' : 'hidden'
        } md:flex flex-col w-full md:w-80 lg:w-96 bg-slate-900 border-r border-slate-700/50 shrink-0`}
      >
        <div className="px-4 py-3 border-b border-slate-700/50 bg-slate-800/30">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-teal-500 flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight">Repeatlay</h1>
          </div>
        </div>

        <ProfileHeader onNavigate={setSidebarView} currentView={sidebarView} />

        <div className="flex-1 overflow-hidden">
          {sidebarView === 'chats' ? (
            <ChatList
              chats={chats}
              loading={loading}
              activeChatId={activeChatId}
              onSelectChat={selectChat}
              onNewGroup={() => setShowNewGroup(true)}
            />
          ) : (
            <UserDiscovery onStartDM={startDM} />
          )}
        </div>
      </div>

      {/* Main chat area */}
      <div
        className={`${
          mobileView === 'chat' ? 'flex' : 'hidden'
        } md:flex flex-1 min-w-0`}
      >
        {activeChat ? (
          <div className="flex-1 flex flex-col min-w-0">
            <ChatView
              chat={activeChat}
              onBack={() => setMobileView('sidebar')}
              onInviteUsers={() => setShowInvite(true)}
            />
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center bg-slate-900 text-center p-8">
            <div className="w-20 h-20 rounded-3xl bg-teal-500/10 flex items-center justify-center mb-4">
              <MessageCircle className="w-10 h-10 text-teal-500" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Welcome to Repeatlay</h2>
            <p className="text-slate-400 max-w-sm">
              Select a chat to start messaging, or discover people to follow and start a conversation.
            </p>
          </div>
        )}
      </div>

      {/* Modals */}
      {showNewGroup && (
        <NewGroupModal onClose={() => setShowNewGroup(false)} onCreated={handleGroupCreated} />
      )}
      {showInvite && activeChat && (
        <InviteUsersModal chat={activeChat} onClose={() => setShowInvite(false)} />
      )}
    </div>
  );
}
