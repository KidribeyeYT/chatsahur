import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type MessageWithSender } from '@/lib/supabase';
import { Reply, Smile, Trash2, MoreVertical, CornerDownRight } from 'lucide-react';

type Props = {
  message: MessageWithSender;
  onReply: (message: MessageWithSender) => void;
};

const EMOJI_CHOICES = ['👍', '❤️', '😂', '😮', '😢', '🔥'];

export function MessageBubble({ message, onReply }: Props) {
  const { profile } = useAuth();
  const [showReactions, setShowReactions] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const isOwn = message.sender_id === profile?.id;
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setShowMenu(false);
        setShowReactions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const senderName = message.sender?.display_name || 'Unknown';
  const initials = senderName
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  // Group reactions by emoji
  const reactionGroups: Record<string, { count: number; hasMine: boolean }> = {};
  for (const r of message.reactions) {
    if (!reactionGroups[r.emoji]) {
      reactionGroups[r.emoji] = { count: 0, hasMine: false };
    }
    reactionGroups[r.emoji].count++;
    if (r.user_id === profile?.id) {
      reactionGroups[r.emoji].hasMine = true;
    }
  }

  async function toggleReaction(emoji: string) {
    if (!profile) return;
    const existing = message.reactions.find((r) => r.emoji === emoji && r.user_id === profile.id);
    if (existing) {
      await supabase.from('reactions').delete().eq('id', existing.id);
    } else {
      await supabase.from('reactions').insert({
        message_id: message.id,
        user_id: profile.id,
        emoji,
      });
    }
    setShowReactions(false);
  }

  async function deleteMessage() {
    if (!profile) return;
    await supabase.from('messages').delete().eq('id', message.id).eq('sender_id', profile.id);
    setShowMenu(false);
  }

  const time = new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className={`group flex gap-2.5 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}>
      {!isOwn && (
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-500 to-slate-700 flex items-center justify-center text-white font-semibold text-xs shrink-0 mt-auto">
          {initials}
        </div>
      )}

      <div className={`flex flex-col max-w-[70%] ${isOwn ? 'items-end' : 'items-start'}`}>
        {!isOwn && (
          <p className="text-xs text-slate-400 mb-1 px-1">
            {senderName}
          </p>
        )}

        <div className="relative" ref={menuRef}>
          <div
            className={`rounded-2xl px-3.5 py-2.5 ${
              isOwn
                ? 'bg-teal-500 text-white rounded-br-sm'
                : 'bg-slate-700/70 text-slate-100 rounded-bl-sm'
            }`}
          >
            {/* Reply preview */}
            {message.reply_to && (
              <div
                className={`mb-2 pl-2.5 border-l-2 rounded ${
                  isOwn ? 'border-teal-200/50 bg-teal-400/20' : 'border-slate-500 bg-slate-600/30'
                } py-1 px-2`}
              >
                <p className={`text-xs font-medium ${isOwn ? 'text-teal-100' : 'text-slate-300'}`}>
                  {message.reply_to.sender_id === profile?.id ? 'You' : 'Replying to message'}
                </p>
                <p className={`text-xs truncate ${isOwn ? 'text-teal-100/80' : 'text-slate-400'}`}>
                  {message.reply_to.content || `[${message.reply_to.media_type}]`}
                </p>
              </div>
            )}

            {/* Media */}
            {message.media_type === 'image' && message.media_url && (
              <img
                src={message.media_url}
                alt="Shared"
                className="rounded-lg max-w-full max-h-72 mb-2 cursor-pointer object-cover"
                onClick={() => window.open(message.media_url!, '_blank')}
              />
            )}
            {message.media_type === 'video' && message.media_url && (
              <video
                src={message.media_url}
                controls
                className="rounded-lg max-w-full max-h-72 mb-2"
              />
            )}

            {/* Text */}
            {message.content && <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>}

            <p className={`text-[10px] mt-1 ${isOwn ? 'text-teal-100/70' : 'text-slate-400'}`}>{time}</p>
          </div>

          {/* Action buttons - visible on hover */}
          <div
            className={`absolute top-0 ${isOwn ? 'left-0 -translate-x-full -ml-1' : 'right-0 translate-x-full ml-1'} opacity-0 group-hover:opacity-100 transition flex items-center gap-0.5`}
          >
            <button
              onClick={() => setShowReactions(!showReactions)}
              className="p-1.5 bg-slate-700/80 hover:bg-slate-600 rounded-lg text-slate-300 transition"
            >
              <Smile className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onReply(message)}
              className="p-1.5 bg-slate-700/80 hover:bg-slate-600 rounded-lg text-slate-300 transition"
            >
              <Reply className="w-3.5 h-3.5" />
            </button>
            <div className="relative">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="p-1.5 bg-slate-700/80 hover:bg-slate-600 rounded-lg text-slate-300 transition"
              >
                <MoreVertical className="w-3.5 h-3.5" />
              </button>
              {showMenu && (
                <div className={`absolute top-full mt-1 ${isOwn ? 'left-0' : 'right-0'} bg-slate-800 border border-slate-700 rounded-lg shadow-xl py-1 z-20 min-w-[120px]`}>
                  {isOwn && (
                    <button
                      onClick={deleteMessage}
                      className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-red-400 hover:bg-slate-700 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Delete
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Reaction picker */}
          {showReactions && (
            <div className={`absolute -top-10 ${isOwn ? 'right-0' : 'left-0'} bg-slate-800 border border-slate-700 rounded-full shadow-xl px-2 py-1 flex items-center gap-0.5 z-20`}>
              {EMOJI_CHOICES.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => toggleReaction(emoji)}
                  className="text-lg hover:scale-125 transition p-1"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Reactions display */}
        {Object.keys(reactionGroups).length > 0 && (
          <div className={`flex flex-wrap gap-1 mt-1 ${isOwn ? 'justify-end' : 'justify-start'}`}>
            {Object.entries(reactionGroups).map(([emoji, info]) => (
              <button
                key={emoji}
                onClick={() => toggleReaction(emoji)}
                className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs transition ${
                  info.hasMine
                    ? 'bg-teal-500/30 border border-teal-500/50'
                    : 'bg-slate-700/60 border border-slate-600/50'
                }`}
              >
                <span>{emoji}</span>
                <span className={isOwn ? 'text-teal-100' : 'text-slate-300'}>{info.count}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
