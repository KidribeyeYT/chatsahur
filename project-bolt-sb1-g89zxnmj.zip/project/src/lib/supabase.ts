import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Profile = {
  id: string;
  username: string;
  display_name: string;
  avatar_url: string | null;
  notifications_enabled: boolean;
  created_at: string;
};

export type Follow = {
  follower_id: string;
  followee_id: string;
  created_at: string;
};

export type Chat = {
  id: string;
  name: string | null;
  type: 'dm' | 'group';
  created_by: string;
  created_at: string;
};

export type ChatMember = {
  chat_id: string;
  user_id: string;
  joined_at: string;
};

export type Message = {
  id: string;
  chat_id: string;
  sender_id: string;
  content: string | null;
  media_url: string | null;
  media_type: 'image' | 'video' | null;
  reply_to_id: string | null;
  created_at: string;
};

export type Reaction = {
  id: string;
  message_id: string;
  user_id: string;
  emoji: string;
  created_at: string;
};

export type MessageWithSender = Message & {
  sender: Profile | null;
  reply_to: Message | null;
  reactions: Reaction[];
};

export type ChatWithMembers = Chat & {
  members: (ChatMember & { profile: Profile })[];
  last_message: Message | null;
};
