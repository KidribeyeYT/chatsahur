import { useCallback, useEffect, useState } from 'react';
import { supabase, type ChatWithMembers, type MessageWithSender } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

export function useChats() {
  const { profile } = useAuth();
  const [chats, setChats] = useState<ChatWithMembers[]>([]);
  const [loading, setLoading] = useState(true);

  const loadChats = useCallback(async () => {
    if (!profile) return;

    const { data: memberships, error: mErr } = await supabase
      .from('chat_members')
      .select('chat_id')
      .eq('user_id', profile.id);

    if (mErr || !memberships?.length) {
      setChats([]);
      setLoading(false);
      return;
    }

    const chatIds = memberships.map((m) => m.chat_id);

    const { data: chatRows, error: cErr } = await supabase
      .from('chats')
      .select('*')
      .in('id', chatIds)
      .order('created_at', { ascending: false });

    if (cErr || !chatRows) {
      setChats([]);
      setLoading(false);
      return;
    }

    const chatsWithMembers: ChatWithMembers[] = await Promise.all(
      chatRows.map(async (chat) => {
        const { data: members } = await supabase
          .from('chat_members')
          .select('chat_id, user_id, joined_at, profile:profiles(*)')
          .eq('chat_id', chat.id);

        const { data: lastMsg } = await supabase
          .from('messages')
          .select('*')
          .eq('chat_id', chat.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        return {
          ...chat,
          members: (members || []).map((m) => ({
            chat_id: m.chat_id,
            user_id: m.user_id,
            joined_at: m.joined_at,
            profile: m.profile as any,
          })),
          last_message: lastMsg as any,
        };
      })
    );

    setChats(chatsWithMembers);
    setLoading(false);
  }, [profile]);

  useEffect(() => {
    loadChats();
  }, [loadChats]);

  // Realtime: listen for new chat_members for this user
  useEffect(() => {
    if (!profile) return;

    const channel = supabase
      .channel('chat_members_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'chat_members', filter: `user_id=eq.${profile.id}` },
        () => loadChats()
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'chats' },
        () => loadChats()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [profile, loadChats]);

  return { chats, loading, reload: loadChats };
}

export function useMessages(chatId: string | null) {
  const [messages, setMessages] = useState<MessageWithSender[]>([]);
  const [loading, setLoading] = useState(true);

  const loadMessages = useCallback(async () => {
    if (!chatId) {
      setMessages([]);
      setLoading(false);
      return;
    }

    const { data: msgs, error } = await supabase
      .from('messages')
      .select('*')
      .eq('chat_id', chatId)
      .order('created_at', { ascending: true });

    if (error || !msgs) {
      setMessages([]);
      setLoading(false);
      return;
    }

    // Load sender profiles
    const senderIds = [...new Set(msgs.map((m) => m.sender_id))];
    const { data: senders } = await supabase
      .from('profiles')
      .select('*')
      .in('id', senderIds);

    // Load reactions
    const msgIds = msgs.map((m) => m.id);
    const { data: reactions } = await supabase
      .from('reactions')
      .select('*')
      .in('message_id', msgIds);

    // Build reply-to map
    const replyIds = msgs.filter((m) => m.reply_to_id).map((m) => m.reply_to_id!) as string[];
    const replyMessages = msgs.filter((m) => replyIds.includes(m.id));

    const senderMap = new Map((senders || []).map((s) => [s.id, s]));
    const reactionMap = new Map<string, any[]>();
    for (const r of reactions || []) {
      const arr = reactionMap.get(r.message_id) || [];
      arr.push(r);
      reactionMap.set(r.message_id, arr);
    }

    const result: MessageWithSender[] = msgs.map((m) => ({
      ...m,
      sender: (senderMap.get(m.sender_id) as any) || null,
      reply_to: (replyMessages.find((rm) => rm.id === m.reply_to_id) as any) || null,
      reactions: reactionMap.get(m.id) || [],
    }));

    setMessages(result);
    setLoading(false);
  }, [chatId]);

  useEffect(() => {
    loadMessages();
  }, [loadMessages]);

  // Realtime subscription for new messages
  useEffect(() => {
    if (!chatId) return;

    const channel = supabase
      .channel(`messages_${chatId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `chat_id=eq.${chatId}` },
        () => loadMessages()
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'messages', filter: `chat_id=eq.${chatId}` },
        () => loadMessages()
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'reactions' },
        () => loadMessages()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [chatId, loadMessages]);

  return { messages, loading, reload: loadMessages };
}
