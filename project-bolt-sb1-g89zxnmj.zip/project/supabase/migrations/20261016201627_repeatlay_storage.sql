/*
# Create storage bucket for media uploads

Creates a public storage bucket 'chat-media' for storing images and videos
that users send in chats. Sets up policies so authenticated users can upload
and read media files.
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-media', 'chat-media', true)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload files
DROP POLICY IF EXISTS "chat_media_upload" ON storage.objects;
CREATE POLICY "chat_media_upload" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'chat-media');

-- Allow anyone to read (public bucket)
DROP POLICY IF EXISTS "chat_media_read" ON storage.objects;
CREATE POLICY "chat_media_read" ON storage.objects FOR SELECT
  TO authenticated USING (bucket_id = 'chat-media');

-- Allow users to delete their own files
DROP POLICY IF EXISTS "chat_media_delete" ON storage.objects;
CREATE POLICY "chat_media_delete" ON storage.objects FOR DELETE
  TO authenticated USING (bucket_id = 'chat-media' AND owner = auth.uid());